package com.example.praktekrecycleview;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.ListViewHolder> {

    private ArrayList<Movie> ListMovie;

    public MovieAdapter(ArrayList<Movie> listMovie) {
        ListMovie = listMovie;
    }

    @NonNull
    @Override
    public MovieAdapter.ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row,parent, false);
        return ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MovieAdapter.ListViewHolder holder, int position) {
       Movie mov = ListMovie.get(position);

       holder.txtTitle.setText(mov.getTitle());
       holder.txtYear.setText(mov.getYear());
    }

    @Override
    public int getItemCount() {
        return ListMovie.size();
    }

    public class ListViewHolder extends RecyclerView.ViewHolder{
        TextView txtTitle;
        TextView txtYear;


        public ListViewHolder(@NonNull View itemView) {
            super(itemView);

            txtTitle = itemView.findViewById(R.id.txtTitle);
            txtYear = itemView.findViewById(R.id.txtYear);
        }
    }
}
